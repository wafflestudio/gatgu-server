# gatgu-server(draft)
team 같이구매 '같구'의  repository 입니다.


- https://github.com/wafflestudio/gatgu-backend/wiki





